using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public int coins;
    public Text coinsText;

    void Awake()
    {
        instance = this;
        coins = PlayerPrefs.GetInt("coins", 0);
    }

    void Start()
    {
        UpdateUI();
    }

    public void AddCoins(int amount)
    {
        coins += amount;
        PlayerPrefs.SetInt("coins", coins);
        UpdateUI();
    }

    void UpdateUI()
    {
        if (coinsText != null)
            coinsText.text = "Coins: " + coins;
    }
}
