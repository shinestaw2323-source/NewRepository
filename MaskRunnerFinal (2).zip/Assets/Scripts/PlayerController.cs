using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 6f;
    public float laneDistance = 2.5f;
    private int lane = 0;

    void Update()
    {
        transform.Translate(Vector3.forward * speed * Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.LeftArrow))
            lane = Mathf.Max(-1, lane - 1);

        if (Input.GetKeyDown(KeyCode.RightArrow))
            lane = Mathf.Min(1, lane + 1);

        Vector3 target = new Vector3(lane * laneDistance, transform.position.y, transform.position.z);
        transform.position = Vector3.Lerp(transform.position, target, 10f * Time.deltaTime);
    }
}
