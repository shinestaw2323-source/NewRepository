using UnityEngine;

public class MaskManager : MonoBehaviour
{
    public GameObject[] masks;
    private int currentMask;

    void Start()
    {
        currentMask = PlayerPrefs.GetInt("mask", 0);
        ActivateMask(currentMask);
    }

    public void BuyMask(int index)
    {
        if (GameManager.instance.coins >= 100)
        {
            GameManager.instance.coins -= 100;
            PlayerPrefs.SetInt("mask", index);
            ActivateMask(index);
        }
    }

    void ActivateMask(int index)
    {
        for (int i = 0; i < masks.Length; i++)
            masks[i].SetActive(i == index);
    }
}
